0. upgrade GVim
aptitude -t wheezy-backports install vim-gnome

1. Install Vundle

mkdir ~/.vim/bundle
cd ~/.vim/bundle

git clone https://github.com/gmarik/Vundle.vim.git vundle

2. Enable vundle_rc.vim

3. Install VimProc

Install VimProc use Vundle
:VimProcInstall

4. Install other bundles
:PluginUpdate
