#!/usr/bin/env python

import sys, os
import mistune

if ('mistune' in sys.modules) == False:
    print ('Please install mistune package:\n  pip install cython\n  pip install mistune')
    sys.exit(1)

if len(sys.argv) < 2:
    sys.exit(2)

file = open(sys.argv[1], 'r');
text = file.read();

print ( mistune.markdown(text, escape=True, hard_wrap=True) )

