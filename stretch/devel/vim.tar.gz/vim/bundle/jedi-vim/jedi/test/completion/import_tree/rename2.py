""" used for renaming tests """


from rename1 import abc

abc
