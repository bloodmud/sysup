"""
It should not be possible to import this pkg except for the import_tree itself,
because it is overwritten there. (It would be possible with a sys.path
modification, though).
"""

foo = 1.0
