def main():
    if True:
	print "single 8 column tab for indentation"
        print "this lines up with previous line"
